//Autonav Team
//February 2021
//ToF sensor class

#ifndef TOF_SENSOR_HPP
#define TOF_SENSOR_HPP

#include "VL53L0X.hpp"

#include "ros/ros.h"
#include "std_msgs/String.h"
#include <ros/console.h>

#include <chrono>
#include <csignal>
#include <exception>
#include <iomanip>
#include <iostream>
#include <unistd.h>

#define WHEEL_TOPIC "wheel_distance"
#define LIGHT_TOPIC "light_state"
#define SENSOR_COUNT 2
#define LEFT_SENSOR_PIN 149
#define RIGHT_SENSOR_PIN 200
#define ROLL_AVG_SIZE 5
#define OBJ_CODE "OBJ,"

class TofSensor 
{
    public:
    //Constructor
    TofSensor();

    //Function to initialize the sensors
    void initSensor();

    //This function is an infinite loop to continue reading the sensors
    //until the program is stopped.
    void spinSensor();

    //This function will perform any cleanup that needs to be done
    //after using the sensors.
    void cleanupSensor();

    //This function is a sigint handler for wheen CTRL-C is pressed.
    //It will set an exit flag.
    static void sigintHandler(int)
    {
        exitFlag = 1;
    }

    private:
    //Function for executing the rolling average
    int filter(int newMeasurement);

    //Arrays for the pins, addresses, and the sensor objects
    const uint8_t pins[SENSOR_COUNT];
    const uint8_t addresses[SENSOR_COUNT];
    VL53L0X** sensors;

    //An exit flag for when CTRL-C has been pressed.
    static volatile sig_atomic_t exitFlag;

    //ROS Node Handle
    ros::NodeHandle node;

    //Publisher to the wheels
    ros::Publisher wheelsPublisher;

    //Publisher to the lights
    ros::Publisher lightsPublisher;

    //Following Direction (-1 for left and 1 for right)
    int followingDir;

    //Rolling Average Array, the sum, and an index for the next measurement
    int pastValues[ROLL_AVG_SIZE];
    int currSum;
    int measurementIndex;
};


#endif //TOF_SENSOR_HPP

