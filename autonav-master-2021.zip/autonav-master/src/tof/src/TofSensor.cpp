//Joshua Kortje
//February 2021
//ToF Sensor Class

#include "TofSensor.hpp"
#include "VL53L0X.hpp"

#include <time.h>
#include <chrono>
#include <csignal>
#include <exception>
#include <iomanip>
#include <iostream>
#include <unistd.h>

//Initialize the static member
volatile sig_atomic_t TofSensor::exitFlag = 0;

//Class Constructor
TofSensor::TofSensor(): pins { LEFT_SENSOR_PIN, RIGHT_SENSOR_PIN }, addresses { VL53L0X_ADDRESS_DEFAULT + 2, VL53L0X_ADDRESS_DEFAULT + 4 }, pastValues {0}
{
    //Initialize the ROS publishers
    this->wheelsPublisher = node.advertise<std_msgs::String>(WHEEL_TOPIC, 1000);
    this->lightsPublisher = node.advertise<std_msgs::String>(LIGHT_TOPIC, 1000);
	// Register SIGINT handler
	signal(SIGINT, sigintHandler);

	// Create sensor objects' array
    this->sensors = new VL53L0X*[SENSOR_COUNT];

    // Create sensors (and ensure GPIO pin mode)
    for (int i = 0; !exitFlag && i < SENSOR_COUNT; ++i) {
        this->sensors[i] = new VL53L0X(pins[i]);
        this->sensors[i]->powerOff();
    }

    //Initialize the rolling average filter
    this->currSum = 0;
    this->measurementIndex = 0;
    
    // Get Ros Params
    if(ros::param::has("/FollowingDirection"))
    {
        ros::param::get("/FollowingDirection", this->followingDir);
    }
    else
    {
        ROS_WARN("Following Polarity not found. Defaulting to right");
        this->followingDir = 1;
    }

    if(this->followingDir == -1)
    {
        this->followingDir = 0;
    }
}

//Function to initialize the sensor
void TofSensor::initSensor()
{
    // Create sensors (and ensure GPIO pin mode)
    for (int i = 0; !exitFlag && i < SENSOR_COUNT; ++i) {
        this->sensors[i] = new VL53L0X(pins[i]);
        this->sensors[i]->powerOff();
    }
	// For each sensor: create object, init the sensor (ensures power on), set timeout and address
	// Note: don't power off - it will reset the address to default!
	for (int i = 0; !this->exitFlag && i < SENSOR_COUNT; ++i) {
		try {
			// Initialize...
			this->sensors[i]->initialize();
			// ...set measurement timeout...
			this->sensors[i]->setTimeout(200);
			// ...set the lowest possible timing budget (high speed mode)...
			this->sensors[i]->setMeasurementTimingBudget(20000);
			// ...and set I2C address...
			this->sensors[i]->setAddress(addresses[i]);
			// ...also, notify user.
			ROS_INFO("Sensor %d initialized, real time budget: %d\n", i, this->sensors[i]->getMeasurementTimingBudget());
		} catch (const std::exception & error) {
            //Error Occured. Set the error flag and output a message
			ROS_ERROR("Error initializing sensor %d  with reason:\n%s\n", i, error.what());
            this->exitFlag = 1;
			return;
		}
    }
}

//Function to loop until the end of the program
void TofSensor::spinSensor()
{
    // Start continuous back-to-back measurement
    try {
        //sensors[this->followingDir]->startContinuous();
    } catch (const std::exception & error) {
        ROS_ERROR("Error starting continuous read mode for sensor %d  with reason:\n%s\n", this->followingDir, error.what());
        this->exitFlag = 1;
        return;
    }
    
    //Setup parameters to capture measurement statistics
    // Durations in nanoseconds
    uint64_t totalDuration = 0;
    uint64_t maxDuration = 0;
    uint64_t minDuration = 1000*1000*1000;
    // Initialize reference time measurement
    std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();

    // We need that variable after the for loop
    int j = 0;
    // Also, set fill and width options for cout so that measurements are aligned
    ROS_INFO_STREAM(std::setw(4) << std::setfill('0'));

    // Take the measurements!
    for (; !this->exitFlag && ros::ok(); ++j) {
        uint16_t distance;
        try {
            // Read the range. Note that it's a blocking call
            distance = this->sensors[this->followingDir]->readRangeSingleMillimeters();
            usleep(20000);
        } catch (const std::exception & error) {
            ROS_ERROR_STREAM(std::endl << "Error geting measurement from sensor " 
                << this->followingDir << " with reason:" << std::endl 
                << error.what() << std::endl);
            // You may want to bail out here, depending on your application 
            //-error means issues on I2C bus read/write.
            // return 3;
            //cleanupSensor();
            std_msgs::String msg;
            msg.data = "Snd_On";
            this->lightsPublisher.publish(msg);
            usleep(500000);
            initSensor();
            msg.data = "Snd_Off";
            this->lightsPublisher.publish(msg);
            distance = 8096;
        }

        if(distance > 1200)
        {
            distance = 1200;
        }

        //Filter
        distance = filter(distance);

        // Check for timeout
        if (this->sensors[this->followingDir]->timeoutOccurred()) {
            ROS_INFO_STREAM("tout | ");
        } else {
            // Display the reading
            ROS_INFO_STREAM(distance << " | ");
            // Make the message
            std_msgs::String msg;
            msg.data = OBJ_CODE + std::to_string(distance);
            this->wheelsPublisher.publish(msg);

        }
        ROS_INFO_STREAM(std::endl << std::flush);

        // Calculate duration of current iteration
        std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
        uint64_t duration = (std::chrono::duration_cast<std::chrono::nanoseconds>(t2 - t1)).count();
        // Save current time as reference for next iteration
        t1 = t2;
        // Add total measurements duration
        totalDuration += duration;
        // Skip comparing first measurement against max and min
        //as it's not a full iteration
        if (j == 0) {
            continue;
        }
        // Check and save max and min iteration duration
        if (duration > maxDuration) {
            maxDuration = duration;
        }
        if (duration < minDuration) {
            minDuration = duration;
        }
    }

    // Print measurement duration statistics
    ROS_INFO_STREAM("\nMax duration: " << maxDuration << "ns" << std::endl);
    ROS_INFO_STREAM("Min duration: " << minDuration << "ns" << std::endl);
    ROS_INFO_STREAM("Avg duration: " << totalDuration/(j+1) << "ns" << std::endl);
    ROS_INFO_STREAM("Avg frequency: " << 1000000000/(totalDuration/(j+1)) 
        << "Hz" << std::endl);
}

//Function to clean up and shut off the sensor GPIO pins
void TofSensor::cleanupSensor()
{
    // Clean-up: delete objects, set GPIO/XSHUT pins to low.
    sensors[this->followingDir]->stopContinuous();
    delete[] this->sensors;
}

//Function for the rolling average filter
//Keep a running total of the current Sum of past N measurements to avoid O(N)
//complexity. Then subtract the obsolete value and add the newMeasurement to 
//get the new sum. Update the array and return the average. 
int TofSensor::filter(int newMeasurement)
{
    this->currSum = this->currSum - this->pastValues[this->measurementIndex] + newMeasurement;
    this->pastValues[this->measurementIndex] = newMeasurement;
    this->measurementIndex = (this->measurementIndex + 1) % ROLL_AVG_SIZE;
    return (this->currSum)/ROLL_AVG_SIZE;
}


int main(int argc, char** argv) {
    ros::init(argc, argv, "tof_sensor", ros::init_options::NoSigintHandler);
    TofSensor* sensing = new TofSensor();
    sensing->initSensor();
    ROS_INFO("Sensors Initialized, getting readings...");
    sensing->spinSensor(); //This call waits until the end of the run
    sensing->cleanupSensor();
    delete sensing;
    ros::shutdown();
	return 0;
}
