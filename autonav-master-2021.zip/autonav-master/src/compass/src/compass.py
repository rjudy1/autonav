#!/usr/bin/env python

# ********************************************* #
# Cedarville University                         #
# AutoNav Senior Design Team 2020-2021          #
# Compass Sensor Class                          #
# ********************************************* #

import sys
sys.path.insert(1, '/home/autonav/autonav_ws/src/autonav_utils')

import py_qmc5883l
import rospy
from autonav_node import AutoNavNode
from std_msgs.msg import String

class Compass(AutoNavNode):
    def __init__(self):
        AutoNavNode.__init__(self, "compass")

        self.compass = py_qmc5883l.QMC5883L()

        self.save_heading_states = set(self.LINE_TO_OBJECT, self.GPS_TO_OBJECT)

        # Publish messages
        self.ANGLE_IN_RANGE = "ANGLE_IN_RANGE"
        self.WAYPOINT_STRAIGHT = "WAYPOINT_STRAIGHT"

        # Read ROS params -- read_param func params are ROS_Param, var_name, default_val
        # self.read_param("/CompassBufferSize", "BUFF_SIZE", 0.2)
        # self.read_param("/ExitAngleGPS", "exit_angle_gps", 45)
        # self.read_param("/ExitAngleLine", "exit_angle_line", 0.2)

        # Publish events that could change the robot state
        self.event_pub = rospy.Publisher("compass_events", String, queue_size=10)

        # Subscribe to state updates for the robot
        self.state_sub = rospy.Subscriber("state_topic", String, self.state_callback)

        # self.outfile = open('/home/autonav/autonav_ws/src/compass/src/compassData.csv', 'w')
        # self.outfile.write('X,Y,Z\n')
        
        # Initialize primary variables
        self.moving_avg = np.zeros((self.BUFF_SIZE,), dtype=bool)
        self.moving_avg_idx = 0
        self.in_range = True

    # a 5 point moving average filter
    def filter_angle(self, new_val):
        self.moving_avg[self.moving_avg_idx] = new_val
        self.moving_avg_idx = (self.moving_avg_idx + 1) % self.BUFF_SIZE
        return np.mean(self.moving_avg)

    # subtracts the angles (x - y) and gives the answer between (-pi, pi]
    def sub_angles(self, x, y):
        a = (x - y + 2 * cmath.pi) % (2 * cmath.pi)
        if a > cmath.pi:
            a -= 2 * cmath.pi
        return a

    # return true if we can switch back from obstacle avoidance to GPS nav
    def in_range(self, error_angle, exit_angle):
        # self.ob_clear_history[self.ob_idx] = 1 if -0.2 < error_angle * -self.following_dir < 0.2  else 0
        # self.ob_idx = (self.ob_idx + 1) % self.ob_clear_history.size
        # return np.count_nonzero(self.ob_clear_history) >= 4
        return abs(error_angle * -self.following_dir) < exit_angle

    # this function takes a measurement and calculates all of the necessary
    # information from the location to send to the motor controller
    def process_compass_data(self):
        self.curr_heading = compass.get_bearing() # read using library function
        # calculate and filter the error in the angle of the two headings
        error_angle = self.sub_angles(self.target_heading, curr_heading)
        filtered_error_angle = self.filter_angle(error_angle)

        # check state, if in object avoid and GPS, then check error_angle for release
        if self.state == self.OBJECT_AVOIDANCE_FROM_GPS:
            if self.in_range(filtered_error_angle, self.exit_angle_gps):
                rospy.logwarn(self.WAYPOINT_STRAIGHT)
                self.safe_publish(self.event_pub, self.WAYPOINT_STRAIGHT)
                # self.ob_clear_history = np.zeros((3,), dtype=np.float32)
        elif self.state == self.OBJECT_AVOIDANCE_FROM_LINE:
            if self.in_range(filtered_error_angle, self.exit_angle_line):
                rospy.logwarn(self.ANGLE_IN_RANGE)
                self.safe_publish(self.event_pub, self.ANGLE_IN_RANGE)
                # self.ob_clear_history = np.zeros((3,), dtype=np.float32)
        
        # rospy.loginfo("%s,%s,%s\n" % (x, y, z))
        # self.outfile.write("%s,%s,%s\n" % (x, y, z))

    def spin_compass(self):
        while not(self.done or rospy.is_shutdown()):
            self.process_compass_data()

    def __del__(self):
        rospy.loginfo("Deleting Compass Node")
        rospy.loginfo("Closing Compass Connection")
        
        #close serial port
        self.ser.break_condition = True 
        self.ser.sendBreak(duration = 0.2)
        time.sleep(0.2)
    
        self.ser.close()
        time.sleep(0.2)
        
        # Close the recording file
        self.outfile.close()
        rospy.loginfo("Cleanup Finished")

    def state_callback(self, new_state):
        rospy.loginfo("New State Received ({}): {}".format(self.node_name, new_state.data))
        self.state = new_state.data
        if self.state in self.save_heading_states:
            self.target_heading = self.curr_heading

def main(args):
    c = Compass()
    spin_thread = Thread(target=c.spin_compass)
    
    try:
        spin_thread.start()
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
    
    spin_thread.join(5)


if __name__ == '__main__':
    main(sys.argv)

