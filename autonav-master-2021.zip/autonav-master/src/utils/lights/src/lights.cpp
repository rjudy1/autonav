// Joshua Kortje
// Implimentation of lights controller
// October 2020

#include <iostream>
#include <unistd.h>
#include "../include/lights/lights.h"


//Constructor for the light controller class
lights::lights(ros::NodeHandle node, const std::string topic)
{
    //Set up all of the controllers for the lights
    redController.open(RED);
    if(!redController.is_open())
    {
        std::cout << "Error opening red light port." << std::endl;
        
    }
    yellowController.open(YELLOW);
    if(!yellowController.is_open())
    {
        std::cout << "Error opening yellow light port." << std::endl;
    }
    greenController.open(GREEN);
    if(!greenController.is_open())
    {
        std::cout << "Error opening green light port." << std::endl;
    }
    soundController.open(SOUND);
    if(!soundController.is_open())
    {
        std::cout << "Error opening sound port." << std::endl;
    }

    //Set up the Subscriber
    this->subscriber = node.subscribe(topic, 1000, &lights::receiveMsg, this);
}

//Destructor
lights::~lights()
{
   //Make sure to turn all lights off before closing
   redLight(eeOff);
   yellowLight(eeOff);
   greenLight(eeOff);
   sound(eeOff);
}

//This method will receive a message from some publisher and send a command 
//to the lights
void lights::receiveMsg(const std_msgs::String::ConstPtr& msg)
{
    std::cout << "Received Message: " << msg->data.c_str() << std::endl;

    //Determine what to do with the message
    if(0 == strcmp(msg->data.c_str(), RED_ON))
    {
        redLight(eeOn);
    }
    else if(0 == strcmp(msg->data.c_str(), RED_OFF))
    {
        redLight(eeOff);
    }
    else if(0 == strcmp(msg->data.c_str(), YELLOW_ON))
    {
        yellowLight(eeOn);
    }
    else if(0 == strcmp(msg->data.c_str(), YELLOW_OFF))
    {
        yellowLight(eeOff);
    }
    else if(0 == strcmp(msg->data.c_str(), GREEN_ON))
    {
        greenLight(eeOn);
    }
    else if(0 == strcmp(msg->data.c_str(), GREEN_OFF))
    {
        greenLight(eeOff);
    }
    else if(0 == strcmp(msg->data.c_str(), SOUND_ON))
    {
        sound(eeOn);
    }
    else if(0 == strcmp(msg->data.c_str(), SOUND_OFF))
    {
        sound(eeOff);
    }
    else
    {
        std::cout << "Invalid Received Message: " << msg->data.c_str() << std::endl;
    }
}

//This function turns the red light on and off
void lights::redLight(OutputState eeOutput)
{
    redController << static_cast<int>(eeOutput) << std::flush;
}

//This function turns the yellow light on and off
void lights::yellowLight(OutputState eeOutput)
{
    yellowController << static_cast<int>(eeOutput) << std::flush;
}

//This function turns the green light on and off
void lights::greenLight(OutputState eeOutput)
{
    greenController << static_cast<int>(eeOutput) << std::flush;
}

//This function turns the sound on and off
void lights::sound(OutputState eeOutput)
{
    soundController << static_cast<int>(eeOutput) << std::flush;
}

int main(int argc, char** argv)
{
    //Initialize the node
    ros::init(argc, argv, "lights");
    ros::NodeHandle node;

    //Test the red light
    lights TestLights(node, LIGHT_TOPIC);

    ros::spin();
    return 0;
}
