// Joshua Kortje
// Class to control the external lights
// October 2020

#ifndef LIGHTS_H
#define LIGHTS_H

#include <fstream>
#include <string>
#include "ros/ros.h"
#include "std_msgs/String.h"

#define RED "/sys/class/gpio/gpio76/value"
#define YELLOW "/sys/class/gpio/gpio77/value"
#define GREEN "/sys/class/gpio/gpio78/value"
#define SOUND "/sys/class/gpio/gpio38/value"

#define RED_ON "R_On"
#define RED_OFF "R_Off"
#define YELLOW_ON "Y_On"
#define YELLOW_OFF "Y_Off"
#define GREEN_ON "G_On"
#define GREEN_OFF "G_Off"
#define SOUND_ON "Snd_On"
#define SOUND_OFF "Snd_Off"

#define LIGHT_TOPIC "light_state"

//Enum for GPIO output
enum OutputState { eeOn = 0, eeOff = 1};

class lights
{
    public:
    //Constructor for the class
    //Pass in the node to make the subscriber
    lights(ros::NodeHandle node, const std::string topic);

    //Destructor
    ~lights();

    //This function acts as a subscriber listening for a command for the lights
    void receiveMsg(const std_msgs::String::ConstPtr& msg);

    //Turns the red light on and off
    void redLight(OutputState eeOutput);

    //Turns the yellow light on and off
    void yellowLight(OutputState eeOutput);

    //Turns the green light on and off
    void greenLight(OutputState eeOutput);

    //Turns the sound on and off
    void sound(OutputState eeOuptut);

    private:
    //Hidden copy constructor and copy assignment operator
    lights(const lights&);
    lights& operator=(const lights&);

    //ROS Subscriber
    ros::Subscriber subscriber;

    //A set of controllers for the light tower (and sound)
    std::ofstream redController;
    std::ofstream yellowController;
    std::ofstream greenController;
    std::ofstream soundController;
};

#endif //LIGHTS_H

