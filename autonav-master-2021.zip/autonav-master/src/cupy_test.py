# Python program to
# demonstrate speed comparison
# between cupy and numpy

# Importing modules
import cupy as cp
import numpy as np
import time

# NumPy and CPU Runtime
s = time.time()
x_cpu = np.ones((1000, 1000, 100))
e = time.time()
print("Time consumed by numpy: ", e - s)

# CuPy and GPU Runtime
s = time.time()
x_gpu = cp.ones((1000, 1000, 100))
e = time.time()
print("Time consumed by cupy: ", e - s)

print()

# NumPy and CPU Runtime
s = time.time()
x_cpu = np.array([1, 2, 3])
l2_cpu = np.linalg.norm(x_cpu)
e = time.time()
print("Time consumed by numpy: ", e - s)

# CuPy and GPU Runtime
s = time.time()
x_gpu = cp.array([1, 2, 3])
l2_gpu = cp.linalg.norm(x_gpu)
e = time.time()
print("Time consumed by cupy: ", e - s)