#!/usr/bin/env python

# ********************************************* #
# Cedarville University                         #
# AutoNav Senior Design Team 2020-2021          #
# Easter Egg Class                              #
# --------------------------------------------- #
# This class is meant to simulate the robots    #
# natural tendencies - enjoy!                   #
# ********************************************* #

import sys
sys.path.insert(1, '/home/autonav/autonav_ws/src/autonav_utils')

import cv2
import os
import random
import rospy
import time
from autonav_node import AutoNavNode
from std_msgs.msg import String

class EasterEgg(AutoNavNode):
    def __init__(self):
        AutoNavNode.__init__(self, "system")

        random.seed()
        # if random.randint(0, 9) != 0: 
        #     rospy.loginfo("System inactive")
        #     return
        rospy.loginfo("System active")
        if not self.execution_count(): return

        # Publish to the lights
        self.BEEP = 0
        self.lights_pub = rospy.Publisher("light_state", String, queue_size=10)
        self.r_on = self.y_on = self.g_on = self.s_on = False

        self.chaos()

    def execution_count(self):
        __location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
        try:
            with open(os.path.join(__location__, "cnt.txt"), "r") as infile:
                cnt_str = infile.read()
                cnt = int(cnt_str) if cnt_str.isdigit() else 0
            with open(os.path.join(__location__, "cnt.txt"), "w") as outfile:
                outfile.write(str(cnt + 1))
        except IOError:
            rospy.loginfo("Error accessing system count file; system shutting down.")
            return False
        if cnt > 10: self.give_hint()
        return True

    def give_hint(self):
        x = random.randint(0, 2)
        rospy.logwarn("Perhaps investigate which ROS node could be issuing such confuzzling commands...")

    def show_image(self):
        img = cv2.imread('./system.jpg')
        cv2.namedWindow("System Failure", cv2.WND_PROP_FULLSCREEN)
        cv2.setWindowProperty("System Failure", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        cv2.imshow("System Failure", img)
        cv2.waitKey(1)

    def pulse_lights(self, state):
        #if state % 4 == 0: self.lights_pub.publish("Snd_On")
        #else: self.lights_pub.publish("Snd_Off")

        if state == 1: self.lights_pub.publish("R_On")
        if state == 2: self.lights_pub.publish("Y_On")
        if state == 3: self.lights_pub.publish("G_On")
        if state == 6: self.lights_pub.publish("R_Off")
        if state == 5: self.lights_pub.publish("Y_Off")
        if state == 4: self.lights_pub.publish("G_Off")

    def pulse_lights_random(self, state):
        x = random.randint(0, 2 + self.BEEP)
        if x == 0:
            if self.r_on:
                self.r_on = False
                self.lights_pub.publish("R_Off")
            else:
                self.r_on = True
                self.lights_pub.publish("R_On")
        elif x == 1:
            if self.y_on:
                self.y_on = False
                self.lights_pub.publish("Y_Off")
            else:
                self.y_on = True
                self.lights_pub.publish("Y_On")
        elif x == 2:
            if self.g_on:
                self.g_on = False
                self.lights_pub.publish("G_Off")
            else:
                self.g_on = True
                self.lights_pub.publish("G_On")
        elif x == 3:
            if self.s_on:
                self.s_on = False
                self.lights_pub.publish("Snd_Off")
            else:
                self.s_on = True
                self.lights_pub.publish("Snd_On")

    def chaos(self):
        state = 1
        while not rospy.is_shutdown():
            self.pulse_lights_random(state)
            state = (state + 1) % 7
            time.sleep(0.1)

def main(args):
    ee = EasterEgg()

    try: rospy.spin()
    except KeyboardInterrupt:
        rospy.loginfo("Keyboard interrupt")
    finally:
        rospy.loginfo("Shutting down system node")

if __name__ == "__main__":
    main(sys.argv)