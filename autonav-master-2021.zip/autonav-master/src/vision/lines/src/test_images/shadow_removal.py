import cv2
import numpy as np

img = cv2.imread('straight_line_shadows_2.png', -1)
# hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
# h, s, v = cv2.split(hsv)
# print(np.mean(v))
# v[v >= 0] = 200
# final_hsv = cv2.merge((h, s, v))
# img = cv2.cvtColor(final_hsv, cv2.COLOR_HSV2RGB)
# cv2.imwrite('shadows_removed.png', img)



# rgb_planes = cv2.split(img)

# result_planes = []
# result_norm_planes = []
# for plane in rgb_planes:
#     dilated_img = cv2.dilate(plane, np.ones((7,7), np.uint8))
#     bg_img = cv2.medianBlur(dilated_img, 21)
#     diff_img = 255 - cv2.absdiff(plane, bg_img)
#     norm_img = cv2.normalize(diff_img,None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8UC1)
#     result_planes.append(diff_img)
#     result_norm_planes.append(norm_img)

# result = cv2.merge(result_planes)
# result_norm = cv2.merge(result_norm_planes)

# cv2.imwrite('shadows_removed.png', result)
# cv2.imwrite('shadows_removed_norm.png', result_norm)


# hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
# h, s, v = cv2.split(hsv)
# s = cv2.medianBlur(s, 11)
# s = cv2.adaptiveThreshold(s, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 401, -10)
# cv2.imwrite('shadows_binary.png', s)


im_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
h, s, v = cv2.split(im_hsv) 

# normalize the chanels we want to minimize
v = cv2.normalize(v, v, 65, 75, cv2.NORM_MINMAX)
s = cv2.normalize(s, s, 65, 75, cv2.NORM_MINMAX)
#h = cv2.bitwise_not(h)

# bring a new hsv image together
hsv_split = np.concatenate((h, s, v))

# extract just the blue value 
filt_col = cv2.cvtColor(im_hsv, cv2.COLOR_HSV2BGR)
blue, green, red  = cv2.split(filt_col)

#blue = cv2.normalize(blue, blue, 0, 200, cv2.NORM_RELATIVE)

grey = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Threshold a single portion of the image and then place that portion on a blank image
ret, grey =  cv2.threshold(grey, 250, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Perform a morphological opening operation on the image
# Uses a rectangular structuring element
element = cv2.getStructuringElement(cv2.MORPH_RECT, (int((7.0 / 1280.0) * grey.shape[0]), int((20.0 / 720.0) * grey.shape[1])))
img = cv2.morphologyEx(grey, cv2.MORPH_OPEN, element)
cv2.imwrite('shadows_removed.png', img)