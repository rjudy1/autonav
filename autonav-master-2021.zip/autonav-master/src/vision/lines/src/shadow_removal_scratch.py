        # Convert to Greyscale and Threshold
        #ret, grey =  cv2.threshold(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        #ret, image =  cv2.threshold(image, 50, 255, cv2.THRESH_BINARY)
        # Display Image
        # if self.TREVOR_DEBUG:
        #     cvDisplay(image, 'Line Detection Thresholded Image', self.window_handle)

    def remove_shadows(self, image):
        # GOOD ONE
        # from scipy.ndimage import gaussian_filter, laplace
        # image_sec_derivative = laplace(image)
        # r, g, b = cv2.split(image_sec_derivative)
        # cvDisplay(r, "R", self.window_handle)
        # cvDisplay(g, "G", self.window_handle)
        # cvDisplay(b, "B", self.window_handle)
        # return image_sec_derivative

        # fgbg = cv2.createBackgroundSubtractorMOG2(128, cv2.THRESH_BINARY, 1)
        # masked_image = fgbg.apply(image)
        # # masked_image[masked_image==127]=0
        # return masked_image

        # s = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        # s = cv2.Laplacian(s, cv2.CV_16S, ksize=3)
        # s = cv2.convertScaleAbs(s)
        # return s

        # gaussian_blur = cv2.GaussianBlur(image,(5,5),sigmaX=0)
        # edges = cv2.Canny(gaussian_blur, 0, 200)
        #return edges

        # HSV FILTERING
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        lower = np.array([0, 65, 100])
        upper = np.array([179, 255, 255])
        mask = cv2.inRange(hsv, lower, upper)
        return mask

        # rgb_planes = cv2.split(image)
        # result_norm_planes = []
        # for plane in rgb_planes:
        #     dilated_img = cv2.dilate(plane, np.ones((7,7), np.uint8))
        #     bg_img = cv2.medianBlur(dilated_img, 21)
        #     diff_img = 255 - cv2.absdiff(plane, bg_img)
        #     norm_img = cv2.normalize(diff_img, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8UC1)
        #     result_norm_planes.append(norm_img)
        # shadowremov = cv2.merge(result_norm_planes)
        # return shadowremov

    def determine_line_shadow(self, image, state):
        slopes = []
        coords = sys.maxsize, -sys.maxsize, -sys.maxsize, sys.maxsize
        if state == "OBJECT_TO_LINE":
            lines = cv2.HoughLinesP(image, 1, np.pi/180, 150, minLineLength=150, maxLineGap=10)
        else:
            lines = cv2.HoughLinesP(image, 1, np.pi/180, 150, minLineLength=250, maxLineGap=10)

        # Temporarily print all lines
        #if lines is not None:
            #image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
            #for line in lines:
                #x1, y1, x2, y2 = line[0]
                #cv2.line(image, (x1, y1), (x2, y2), (255, 0, 0), thickness=2)
            #cv2.imshow("All Lines", image)
            #cv2.waitKey(2)

        if lines is not None:
            for line in lines[:4]:
                #print("COORDS: {}".format(line[0]))
                x1, y1, x2, y2 = line[0]
                slopes.append(self.get_slope(x1, y1, x2, y2))
                coords = min(x1, coords[0]), max(y1, coords[1]), max(x2, coords[2]), min(y2, coords[3])
            print("STD DEV: {}".format(np.std(slopes)))
            if np.std(slopes) <= 1:
                self.update_history(1)
                self.slope = np.average(slopes)
                self.distance = self.get_distance(image.shape[1], image.shape[0], coords)
                rospy.logwarn("LINE SLOPE: {} | LINE DISTANCE: {}".format(self.slope, self.distance))
                return True, coords