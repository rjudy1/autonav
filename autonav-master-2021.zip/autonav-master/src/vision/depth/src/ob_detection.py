#!/usr/bin/env python

# ********************************************* #
# Cedarville University                         #
# AutoNav Senior Design Team 2020-2021          #
# Obstacle Detection Class                      #
# ********************************************* #

import sys
sys.path.insert(1, '/home/autonav/autonav_ws/src/autonav_utils')

import cv2
import numpy as np
import rospy
from autonav_node import AutoNavNode
from sensor_msgs.msg import Image, CameraInfo
from std_msgs.msg import String, Float64MultiArray

# Start RealSense Publisher: $ rosrun rs_publisher publish.py
# Run This Script: $ rosrun depth ob_detection.py

class ObstacleDetection(AutoNavNode):
    def __init__(self):
        AutoNavNode.__init__(self, "ob_detection")

        # States
        self.OBJECT_SEEN = "OBJECT_SEEN"
        self.PATH_CLEAR = "PATH_CLEAR"

        # Read ROS params -- read_param func params are ROS_Param, var_name, default_val
        self.read_param("/ObjectBufferSize", "BUFF_SIZE", 3)
        self.read_param("/ObjectBufferFill", "BUFF_FILL", 0.8)
        self.read_param("/ObjectStopDistance", "DISTANCE_AT_WHICH_WE_STOP_FROM_THE_OBSTACLE", 1.5)

        # Publish events that could change the robot state
        self.event_pub = rospy.Publisher("depth_events", String, queue_size=10)

        # Subscribe to the camera depth topic
        self.image_sub = rospy.Subscriber("/camera/depth/image_rect_raw", Float64MultiArray, self.image_callback, queue_size=1, buff_size=2**24)

        # Subscribe to state updates for the robot
        self.state_sub = rospy.Subscriber("state_topic", String, self.state_callback)

        # Scale to convert depth image to distance
        self.DEPTH_SCALE = 0.0010000000475

        # Initialize primary variables
        self.history = np.zeros((self.BUFF_SIZE,), dtype=bool)
        self.history_idx = 0
        self.path_clear = True

        rospy.loginfo("Waiting for image topics...")

    def get_hist(self, img):
        return np.sum(img, axis=0)

    def determine_obstacle(self, min_distance):
        self.history[self.history_idx] = 1 if min_distance < self.DISTANCE_AT_WHICH_WE_STOP_FROM_THE_OBSTACLE else 0
        self.history_idx = (self.history_idx + 1) % self.BUFF_SIZE

    def determine_state(self):
        if self.path_clear and np.count_nonzero(self.history) >= self.BUFF_FILL * self.BUFF_SIZE:
            rospy.loginfo(self.OBJECT_SEEN)
            self.safe_publish(self.event_pub, self.OBJECT_SEEN)
            self.path_clear = False
        elif (self.state == self.LINE_TO_OBJECT or self.state == self.GPS_TO_OBJECT) and np.count_nonzero(self.history) <= (1 - self.BUFF_FILL) * self.BUFF_SIZE:
            rospy.loginfo(self.PATH_CLEAR)
            self.safe_publish(self.event_pub, self.PATH_CLEAR)
            self.path_clear = True

    def reset(self):
        self.history = np.zeros((self.BUFF_SIZE,), dtype=bool)
        self.path_clear = True

    def image_callback(self, depth_arr):
        # Reshape 1-D List back to 2-D Numpy Array
        height, width = depth_arr.layout.dim[0].size, depth_arr.layout.dim[1].size
        depth_arr = np.asanyarray(depth_arr.data, dtype=np.float64).reshape(height, width)

        # Determine Pixel Distances
        distances = depth_arr * self.DEPTH_SCALE
        distances[distances == 0] = 10 # TODO check if distance < value or just 0?

        min_dist = np.min(distances)
        if self.is_debug: print("Distance: {:.2f} | Object: {}".format(min_dist, not self.path_clear))

        self.determine_obstacle(min_dist)
        self.determine_state()


def main(args):
    od = ObstacleDetection()

    try: rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down obstacle detection node.")
        cv2.destroyAllWindows()
    finally:
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main(sys.argv)
